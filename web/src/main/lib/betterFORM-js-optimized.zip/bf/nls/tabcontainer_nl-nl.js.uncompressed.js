define('bf/nls/tabcontainer_nl-nl',{
'dijit/nls/loading':{"loadingState":"Bezig met laden...","errorState":"Er is een fout opgetreden"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Annuleren","buttonSave":"Opslaan","itemClose":"Sluiten"}
});