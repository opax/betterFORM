define('bf/nls/dates_es-es',{
'dijit/form/nls/ComboBox':{"previousMessage":"Opciones anteriores","nextMessage":"Más opciones"}
,
'dijit/form/nls/validate':{"rangeMessage":"Este valor está fuera del intervalo.","invalidMessage":"El valor especificado no es válido.","missingMessage":"Este valor es necesario."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});