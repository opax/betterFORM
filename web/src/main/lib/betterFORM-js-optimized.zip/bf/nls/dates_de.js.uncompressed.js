define('bf/nls/dates_de',{
'dijit/form/nls/ComboBox':{"previousMessage":"Vorherige Auswahl","nextMessage":"Weitere Auswahlmöglichkeiten"}
,
'dijit/form/nls/validate':{"rangeMessage":"Dieser Wert liegt außerhalb des gültigen Bereichs. ","invalidMessage":"Der eingegebene Wert ist ungültig. ","missingMessage":"Dieser Wert ist erforderlich."}
,
'bf/input/nls/DropDownDate':{"july":"Juli","april":"April","october":"Oktober","may":"Mai","november":"November","january":"Januar","december":"Dezember","february":"Februar","june":"Juni","august":"August","september":"September","march":"März"}
});