define('bf/nls/dates_hu',{
'dijit/form/nls/ComboBox':{"previousMessage":"Előző menüpontok","nextMessage":"További menüpontok"}
,
'dijit/form/nls/validate':{"rangeMessage":"Az érték kívül van a megengedett tartományon.","invalidMessage":"A megadott érték érvénytelen.","missingMessage":"Meg kell adni egy értéket."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});