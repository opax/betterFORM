define('bf/nls/tabcontainer_de',{
'dijit/nls/loading':{"loadingState":"Wird geladen...","errorState":"Es ist ein Fehler aufgetreten."}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Abbrechen","buttonSave":"Speichern","itemClose":"Schließen"}
});