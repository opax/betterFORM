define('bf/nls/dates_nl-nl',{
'dijit/form/nls/ComboBox':{"previousMessage":"Eerdere opties","nextMessage":"Meer opties"}
,
'dijit/form/nls/validate':{"rangeMessage":"Deze waarde is niet toegestaan.","invalidMessage":"De opgegeven waarde is ongeldig.","missingMessage":"Deze waarde is verplicht."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});