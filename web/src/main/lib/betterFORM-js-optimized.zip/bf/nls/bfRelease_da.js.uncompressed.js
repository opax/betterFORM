define('bf/nls/bfRelease_da',{
'dijit/form/nls/validate':{"rangeMessage":"Værdien er uden for intervallet.","invalidMessage":"Den angivne værdi er ugyldig.","missingMessage":"Værdien er påkrævet."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
,
'dijit/nls/loading':{"loadingState":"Indlæser...","errorState":"Der er opstået en fejl"}
,
'dojo/cldr/nls/number':{"scientificFormat":"#E0","currencySpacing-afterCurrency-currencyMatch":"[:letter:]","infinity":"∞","list":",","percentSign":"%","minusSign":"-","currencySpacing-beforeCurrency-surroundingMatch":"[:digit:]","decimalFormat-short":"000 bill","currencySpacing-afterCurrency-insertBetween":" ","nan":"NaN","plusSign":"+","currencySpacing-afterCurrency-surroundingMatch":"[:digit:]","currencyFormat":"#,##0.00 ¤","currencySpacing-beforeCurrency-currencyMatch":"[:letter:]","perMille":"‰","group":".","percentFormat":"#,##0 %","decimalFormat-long":"000 billioner","decimalFormat":"#,##0.###","decimal":",","currencySpacing-beforeCurrency-insertBetween":" ","exponential":"E"}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Forrige valg","nextMessage":"Flere valg"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Annullér","buttonSave":"Gem","itemClose":"Luk"}
});