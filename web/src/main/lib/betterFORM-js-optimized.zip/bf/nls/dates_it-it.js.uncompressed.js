define('bf/nls/dates_it-it',{
'dijit/form/nls/ComboBox':{"previousMessage":"Scelte precedenti","nextMessage":"Scelte successive"}
,
'dijit/form/nls/validate':{"rangeMessage":"Questo valore è fuori dall'intervallo consentito.","invalidMessage":"Il valore immesso non è valido.","missingMessage":"Questo valore è obbligatorio."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});