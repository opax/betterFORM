define('bf/nls/tabcontainer_pl',{
'dijit/nls/loading':{"loadingState":"Ładowanie...","errorState":"Niestety, wystąpił błąd"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Anuluj","buttonSave":"Zapisz","itemClose":"Zamknij"}
});