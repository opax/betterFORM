define('bf/nls/dates_da',{
'dijit/form/nls/ComboBox':{"previousMessage":"Forrige valg","nextMessage":"Flere valg"}
,
'dijit/form/nls/validate':{"rangeMessage":"Værdien er uden for intervallet.","invalidMessage":"Den angivne værdi er ugyldig.","missingMessage":"Værdien er påkrævet."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});