define('bf/nls/tabcontainer_fr-fr',{
'dijit/nls/loading':{"loadingState":"Chargement...","errorState":"Une erreur est survenue"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Annuler","buttonSave":"Enregistrer","itemClose":"Fermer"}
});