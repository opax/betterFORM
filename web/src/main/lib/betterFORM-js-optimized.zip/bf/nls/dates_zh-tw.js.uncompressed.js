define('bf/nls/dates_zh-tw',{
'dijit/form/nls/ComboBox':{"previousMessage":"前一個選擇項","nextMessage":"其他選擇項"}
,
'dijit/form/nls/validate':{"rangeMessage":"此值超出範圍。","invalidMessage":"輸入的值無效。","missingMessage":"必須提供此值。"}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});