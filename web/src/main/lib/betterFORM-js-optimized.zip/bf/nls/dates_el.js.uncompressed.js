define('bf/nls/dates_el',{
'dijit/form/nls/ComboBox':{"previousMessage":"Προηγούμενες επιλογές","nextMessage":"Περισσότερες επιλογές"}
,
'dijit/form/nls/validate':{"rangeMessage":"Η τιμή αυτή δεν ανήκει στο εύρος έγκυρων τιμών.","invalidMessage":"Η τιμή που καταχωρήσατε δεν είναι έγκυρη.","missingMessage":"Η τιμή αυτή πρέπει απαραίτητα να καθοριστεί."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});