define('bf/nls/tabcontainer_nb',{
'dijit/nls/loading':{"loadingState":"Laster inn...","errorState":"Det oppsto en feil"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Avbryt","buttonSave":"Lagre","itemClose":"Lukk"}
});