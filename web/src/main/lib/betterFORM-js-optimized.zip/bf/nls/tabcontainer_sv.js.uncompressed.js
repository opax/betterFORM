define('bf/nls/tabcontainer_sv',{
'dijit/nls/loading':{"loadingState":"Läser in...","errorState":"Det har inträffat ett fel."}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Avbryt","buttonSave":"Spara","itemClose":"Stäng"}
});