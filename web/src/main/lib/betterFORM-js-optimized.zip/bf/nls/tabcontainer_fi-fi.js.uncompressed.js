define('bf/nls/tabcontainer_fi-fi',{
'dijit/nls/loading':{"loadingState":"Lataus on meneillään...","errorState":"On ilmennyt virhe."}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Peruuta","buttonSave":"Tallenna","itemClose":"Sulje"}
});