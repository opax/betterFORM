define('bf/nls/tabcontainer_he-il',{
'dijit/nls/loading':{"loadingState":"טעינה...","errorState":"אירעה שגיאה"}
,
'dijit/nls/common':{"buttonOk":"אישור","buttonCancel":"ביטול","buttonSave":"שמירה","itemClose":"סגירה"}
});