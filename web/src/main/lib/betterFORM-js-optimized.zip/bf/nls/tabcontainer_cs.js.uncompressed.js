define('bf/nls/tabcontainer_cs',{
'dijit/nls/loading':{"loadingState":"Probíhá načítání...","errorState":"Omlouváme se, došlo k chybě"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Storno","buttonSave":"Uložit","itemClose":"Zavřít"}
});