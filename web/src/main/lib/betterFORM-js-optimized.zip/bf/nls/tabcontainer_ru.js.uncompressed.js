define('bf/nls/tabcontainer_ru',{
'dijit/nls/loading':{"loadingState":"Загрузка...","errorState":"Извините, возникла ошибка"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Отмена","buttonSave":"Сохранить","itemClose":"Закрыть"}
});