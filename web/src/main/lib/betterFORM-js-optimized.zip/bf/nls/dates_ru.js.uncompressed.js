define('bf/nls/dates_ru',{
'dijit/form/nls/ComboBox':{"previousMessage":"Предыдущие варианты","nextMessage":"Следующие варианты"}
,
'dijit/form/nls/validate':{"rangeMessage":"Это значение вне диапазона.","invalidMessage":"Указано недопустимое значение.","missingMessage":"Это обязательное значение."}
,
'bf/input/nls/DropDownDate':{"july":"July","april":"April","october":"October","may":"May","november":"November","january":"January","december":"December","february":"February","june":"June","august":"August","september":"September","march":"March"}
});