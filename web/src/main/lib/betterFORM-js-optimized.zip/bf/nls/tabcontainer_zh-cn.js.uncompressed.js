define('bf/nls/tabcontainer_zh-cn',{
'dijit/nls/loading':{"loadingState":"正在加载...","errorState":"对不起，发生了错误"}
,
'dijit/nls/common':{"buttonOk":"确定","buttonCancel":"取消","buttonSave":"保存","itemClose":"关闭"}
});