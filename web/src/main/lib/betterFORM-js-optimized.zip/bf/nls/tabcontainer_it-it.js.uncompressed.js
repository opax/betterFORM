define('bf/nls/tabcontainer_it-it',{
'dijit/nls/loading':{"loadingState":"Caricamento in corso...","errorState":"Si è verificato un errore"}
,
'dijit/nls/common':{"buttonOk":"Ok","buttonCancel":"Annulla","buttonSave":"Salva","itemClose":"Chiudi"}
});