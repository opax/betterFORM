define("bf/input/nls/DropDownDate", { root:
//begin v1.x content
    ({
        january:"January",
        february:"February",
        march:"March",
        april:"April",
        may:"May",
        june:"June",
        july:"July",
        august:"August",
        september:"September",
        october:"October",
        november:"November",
        december:"December"

    })
//end v1.x content
    ,
    "de": true
});
